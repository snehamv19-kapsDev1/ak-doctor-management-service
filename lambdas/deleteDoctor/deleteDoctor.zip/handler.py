from common.s3_repo import read_all, write_all
from common.utils import response

def handler(event, context):
    doc_id = event["pathParameters"]["id"]

    rows = read_all()
    new_rows = [r for r in rows if r["id"] != doc_id]

    if len(rows) == len(new_rows):
        return response(404, {"message": "Not found"})

    write_all(new_rows)

    return response(200, {"message": "Deleted"})