import json
from common.s3_repo import read_all, write_all
from common.utils import response

def handler(event, context):
    body = json.loads(event["body"])

    rows = read_all()

    for r in rows:
        if r["id"] == body["id"]:
            return response(400, {"message": "Doctor exists"})

    rows.append(body)
    write_all(rows)

    return response(201, body)