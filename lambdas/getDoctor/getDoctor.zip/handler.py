from common.s3_repo import read_all
from common.utils import response

def handler(event, context):
    doc_id = event["pathParameters"]["id"]

    for r in read_all():
        if r["id"] == doc_id:
            return response(200, r)

    return response(404, {"message": "Not found"})