import json
from common.s3_repo import read_all, write_all
from common.utils import response

def handler(event, context):
    doc_id = event["pathParameters"]["id"]
    body = json.loads(event["body"])

    rows = read_all()

    for i, r in enumerate(rows):
        if r["id"] == doc_id:
            rows[i].update(body)
            write_all(rows)
            return response(200, rows[i])

    return response(404, {"message": "Not found"})